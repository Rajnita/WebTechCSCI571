
***************************** VARIATION 1 *****************************

To reflect in the front-end UI, changes are made in create.js, edit.js and recordlist.js,navbar.js (for the button name) under Client.
The modified files for client are put under client directory in the zip file. Similarly for server.
No changes were made in server.js and App.js. Hence, not included in the submission.

For server, the database and table are given appropriate names to reflect the three fields I chose (Books table and fields as title,genre, author).

For Client related files that were updated, please check under 'client' directory.
For Server related files that were updated, please check under 'server' directory.
Two Screenshots are added -
Variation1_MongoAtlas_Screenshot - showing atlas screen as asked in HW description
Variation1_UI_Screenshot - the UI screen

As per https://piazza.com/class/kyeg608so5gf5?cid=348, it's okay to submit extra screenshots, rename database appropriately.

