***************************** VARIATION 2*****************************

App.js is edited to reflect the three fields I chose (movie title, genre and director).
Similarly, server.js file is edited to reflect the three fields

2 screenshots
- One for UI
- One for MongoAtlas Screen as asked in hw description
